import React from "react";
import "./footer.css";
import App from './App';



function footer() {
    <footer className="footer">
        <div className="container">
            <div className="footer__socials">
                <a href="/" className="footer__social">Face</a>
                <a href="/" className="footer__social">Insta</a>
                <a href="/" className="footer__social">Twitter</a>
                <a href="/" className="footer__social">Youtube</a>

            </div>

            <ul className="footer__links">
                <li className="footer__link">
                    <a href="/">Lien footer</a>
                </li>

                <li className="footer__link">
                    <a href="/">Lien footer</a>
                </li>

                <li className="footer__link">
                    <a href="/">Lien footer</a>
                </li>

                <li className="footer__link">
                    <a href="/">Lien footer</a>
                </li>

                <li className="footer__link">
                    <a href="/">Lien footer</a>
                </li>

                <li className="footer__link">
                    <a href="/">Lien footer</a>
                </li>

                <li className="footer__link">
                    <a href="/">Lien footer</a>
                </li>
            </ul>
            <div className="footer__copy">
                ©2022 Clone Slack Technologies, LLC, une entreprise Salesforce. Tous droits réservés. Les différentes marques commerciales appartiennent à leurs propriétaires respectifs.
            </div>
        </div>

    </footer>
}

export default footer;