import React from 'react';
import { useState } from 'react';
import './nav.css';



function nav() {

    const [navwhite, setnavwhite] = useState(false);
    const [toggleMenu, settoggleMenu] = useState(false);

    const transitionnav = () => {
        window.scrollY > 100 ? setnavwhite(true) : setnavwhite(false);
    };

    useState(() => {
        document.addEventListener["scroll", transitionnav];
    });

    const handleClick = () => {
        console.log(toggleMenu);
        toggleMenu ? settoggleMenu(false) : settoggleMenu(true)
    }


    return (
        <div className={'nav ${navwhite && "nav--white"} ${toggleMenu && "show"}'}>
            <button className="nav__burger" onClick={handleClick}>
            </button>
            <img src="./img/logoSlack.svg.png" className="nav__logo" alt="Slack" />

            <nav className="nav__links">
                <a href="/" className="nav__link">Produit</a>
                <a href="/" className="nav__link">Pour les Entreprises</a>
                <a href="/" className="nav__link">Ressources</a>
                <a href="/" className="nav__link">Tarifs</a>
                <a href="/" className="nav__link">Connexion</a>

            </nav >

            <div className='nav__actions'>
                <a href='/' className='nav__action'>CONTACTER NOTRE EQUIPE COMMERCIALE</a>
                <a href='/' className='nav__action'>ESSAI GRATUIT</a>


            </div >
        </div >
    );
}

export default nav;