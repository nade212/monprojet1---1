import "./App.css";
import nav from "./components/nav";
import footer from "./components/footer";
import formulaire from "./components/formulaire";
import index from "./components/index";


function App() {
  return (
    <div className="App">
      {/* navbar */}
      <nav />

      {/* banner */}

      {/* rows */}

      {/* video */}

      {/* quick view */}

      {/* footer */}

    </div >
  );
}

export default App;
