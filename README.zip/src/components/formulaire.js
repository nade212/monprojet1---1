import React from "react";
import "./formulaire.css";
import App from './App';

<main id="main" role="main">

    <section class="o-section v--borderless section-contact-sales-hero t-dark-theme">

        <div class="o-content-container">

            <div class="o-two-columns v--even-large v--contact-sales-form-grid">

                <div class="section-contact-sales-hero__copy">

                    <h1 class="u-margin-bottom--medium u-margin-top--flush">Contacter notre équipe commerciale</h1>
                    <p>Nous sommes ravis de répondre à vos questions et de vous présenter Slack.</p>
                    <div class="section-contact-sales-hero__list">
                        <div class="section-contact-sales-hero__list__item">
                            <div class="section-contact-sales-hero__list__item-check">
                                <svg class="c-check" width="14" height="14" xmlns="http://www.w3.org/2000/svg" viewBox="-255 347 100 100">
                                    <title></title>
                                    <path d="M-217.1 431.8c-1 1.2-2.6 2.2-4 2.3-1.4.1-3-.8-4.3-1.9l-27.5-24.5 7.8-8.7 23.2 20.6 54.6-61.7 8.6 7.9-58.4 66z"></path>
                                </svg>
                            </div>

                            <div class="section-contact-sales-hero__list__item-text">
                                <p>Recevoir des informations tarifaires</p>
                            </div>
                        </div>
                        <div class="section-contact-sales-hero__list__item">
                            <div class="section-contact-sales-hero__list__item-check">
                                <svg class="c-check" width="14" height="14" xmlns="http://www.w3.org/2000/svg" viewBox="-255 347 100 100">
                                    <title></title>
                                    <path d="M-217.1 431.8c-1 1.2-2.6 2.2-4 2.3-1.4.1-3-.8-4.3-1.9l-27.5-24.5 7.8-8.7 23.2 20.6 54.6-61.7 8.6 7.9-58.4 66z"></path>
                                </svg>
                            </div>
                            <div class="section-contact-sales-hero__list__item-text">

                                <p>Découvrir des cas d’utilisation pour votre équipe</p>
                            </div>
                        </div>
                    </div>
                    <div class="section-contact-sales-hero__list__item">
                        <div class="section-contact-sales-hero__list__item-check">
                            <svg class="c-check" width="14" height="14" xmlns="http://www.w3.org/2000/svg" viewBox="-255 347 100 100">
                                <title></title>
                                <path d="M-217.1 431.8c-1 1.2-2.6 2.2-4 2.3-1.4.1-3-.8-4.3-1.9l-27.5-24.5 7.8-8.7 23.2 20.6 54.6-61.7 8.6 7.9-58.4 66z"></path>
                            </svg>
                        </div>
                        <div class="section-contact-sales-hero__list__item-text">
                            <p>Recevoir des informations tarifaires</p>
                        </div>
                    </div>
                    <div class="u-margin-top--xx-large">
                        <p class="u-text--small">Pour toute question technique et demande générale, veuillez »
                            <a class="t-reverse-link" data-clog-click="" data-clog-element="link_help_contact" href="https://slack.com/intl/fr-fr/help/contact" rel="noopener">vous rendre sur notre centre d’assistance</a>.
                        </p>
                    </div>
                </div>
                <div class="section-contact-sales-hero__empty">
                </div>
            </div>
        </div>
    </section>
    <section class="o-section v--borderless section-contact-sales-form">
        <div class="o-content-container v--contact-sales-form-container">
            <div class="o-two-columns v--even-large v--contact-sales-form-grid v--desktop-inverse">
                <div class="section-contact-sales-form__copy">
                    <div class="o-content-container v--contact-sales-form-copy-container">
                        <section class="o-section o-section--feature-companies v--borderless u-padding-bottom--flush" />
                        <div class="o-content-container u-text--center ">
                            <h2 class="u-margin-top--large u-margin-bottom--x-large">De formidables entreprises utilisent Slack</h2>
                            <div class="o-section--feature-companies__logos">
                            </div>
                            <img style="" src="https://a.slack-edge.com/a61326/marketing/img/logos/company/_color/deezer.png"
                                srcset="https://a.slack-edge.com/a61326/marketing/img/logos/company/_color/deezer.png 1x,
                                        https://a.slack-edge.com/6627a/marketing/img/logos/company/_color/deezer@2x.png 2x" alt="Deezer" width="147" />
                        </div>
                    </div>
                </div>
                <div>
                    <img style="" src="https://a.slack-edge.com/e2fa17/marketing/img/logos/company/_color/airbnb-logo.png"
                        srcset="https://a.slack-edge.com/e2fa17/marketing/img/logos/company/_color/airbnb-logo.png 1x, 
                                        https://a.slack-edge.com/80588/marketing/img/logos/company/_color/airbnb-logo@2x.png 2x" alt="Airbnb" width="112" />
                </div>

                <div>
                    <img style="" src="https://a.slack-edge.com/68794/marketing/img/logos/company/_color/criteo.png"
                        srcset="https://a.slack-edge.com/68794/marketing/img/logos/company/_color/criteo.png 1x, 
                                        https://a.slack-edge.com/68794/marketing/img/logos/company/_color/criteo@2x.png 2x" alt="Criteo" width="111" />
                </div>

                <div>
                    <img style="" src="https://a.slack-edge.com/68794/marketing/img/logos/company/_color/le-monde.png"
                        srcset="https://a.slack-edge.com/68794/marketing/img/logos/company/_color/le-monde.png 1x, 
                                        https://a.slack-edge.com/68794/marketing/img/logos/company/_color/le-monde@2x.png 2x" alt="Le Monde" width="131" />
                </div>

                <div>
                    <img style="" src="https://a.slack-edge.com/65573/marketing/img/logos/company/_color/blablacar.png"
                        srcset="https://a.slack-edge.com/65573/marketing/img/logos/company/_color/blablacar.png 1x,
                                        https://a.slack-edge.com/65573/marketing/img/logos/company/_color/blablacar@2x.png 2x" alt="Blablacar" width="143" />
                </div>

                <div>
                    <img style="" src="https://a.slack-edge.com/ce67d/marketing/img/logos/company/_color/m6.png"
                        srcset="https://a.slack-edge.com/ce67d/marketing/img/logos/company/_color/m6.png 1x,
                                        https://a.slack-edge.com/68794/marketing/img/logos/company/_color/m6@2x.png 2x" alt="M6" width="59" />
                </div>

                <div>
                    <img style="" src="https://a.slack-edge.com/f854ec/marketing/img/logos/company/_color/veepee.png"
                        srcset="https://a.slack-edge.com/f854ec/marketing/img/logos/company/_color/veepee.png 1x,
                                        https://a.slack-edge.com/f854ec/marketing/img/logos/company/_color/veepee@2x.png 2x" alt="Veepee" width="126" />
                </div>
            </div>
        </div>

        <div class="v--padded" aria-hidden="true">
            <div class="c-card--customer v--showcase">
                <div class="c-card--customer__testimonial u-margin-top--flush u-margin-bottom--flush">
                    <figure>
                        <img class="c-card--customer__logo v--showcase" src="https://a.slack-edge.com/f854ec/marketing/img/logos/company/_color/deliveroo.png"
                            srcset="https://a.slack-edge.com/f854ec/marketing/img/logos/company/_color/deliveroo.png 1x, 
                                        https://a.slack-edge.com/f854ec/marketing/img/logos/company/_color/deliveroo@2x.png 2x" alt="Deliveroo" />
                    </figure>

                    <span class="c-card--customer__quote">« Slack a révolutionné notre manière de travailler,
                        [c'est] le canal de communication préféré dans notre entreprise, et le seul que nous apprécions réellement.
                        [...] Slack est tout sauf rigide dans son utilisation, nous l'avons personnalisé intégralement afin qu’il réponde à nos besoins. »</span>

                    <span class="c-card--customer__name">Will Sprunt</span>
                    <span class="c-card--customer__title">Directeur des systèmes d’information, Deliveroo</span>
                </div>
            </div>
        </div>

        <div class="section-contact-sales-form__form u-overflow--visible o-overflow-container" />
        <div class="c-form__wrap--inline u-padding--flush u-margin--centered">
            <div class="c-shadowbox">
                <form class="c-form v--vertical--spaced" name="contact_sales_form"
                    id="contact_sales_form" action="/intl/fr-fr/contact-sales?geocode=fr-fr" method="post" novalidate="" />
                <div class="c-form__notifications u-margin-bottom--flush">
                </div>
            </div>
        </div>

        <input type="hidden" name="crumb" value="s-1644179776-790fffb3ec3edea8c34143c94e0e05d49ddeae1bf215eff63586b946179db7fc-☃" />
        <div class="o-two-columns v--even">
            <fieldset class="u-margin-top--flush" id="">
                <label class="c-form__label" for="first_name">Prénom<span class="is-error"> *</span>
                </label>
            </fieldset>

            <input autocomplete="given-name" class="c-form__input has-error" data-value-missing="Veuillez indiquer votre prénom.
                    " id="first_name" maxlength="80" name="first_name" placeholder="Votre prénom" required="" type="text" />
            <div class="c-form__inline-error u-margin-bottom--small" aria-live="polite">Veuillez indiquer votre prénom.
            </div>

            <fieldset class="u-margin-top--flush" id="">
                <label class="c-form__label" for="last_name">Nom de famille<span class="is-error"> *</span>
                </label>

                <input autocomplete="family-name" class="c-form__input has-error" data-value-missing="Veuillez indiquer votre nom de famille.
                    " id="last_name" maxlength="80" name="last_name" placeholder="Votre nom de famille" required="" type="text" />
                <div class="c-form__inline-error u-margin-bottom--small" aria-live="polite">Veuillez indiquer votre nom de famille.
                </div>
            </fieldset>
        </div>

        <fieldset class="u-margin-top--flush">
            <label class="c-form__label" for="email">Adresse e-mail professionnelle<span class="is-error"> *</span>
            </label>

            <input autocomplete="email" class="c-form__input" data-value-invalid="Oups&nbsp;! Il semble que cette adresse e-mail ne soit pas valide." data-value-missing="Veuillez fournir une adresse e-mail." id="email" name="email" pattern="^([\w.-]+)@(\[(\d{1,3}\.){3}|(([a-zA-Z\d-]+\.)+))([a-zA-Z]{2,15}|\d{1,3})(\]?)$" placeholder="exemple@abc.com" required="" type="email"><div class="c-form__inline-error u-margin-bottom--small hide" aria-live="polite">
            </div>
            </input>

        </fieldset>
        <div class="v--even" id="state_country_wrapper">
            <div class="c-form__state-field hide" id="state_field">
                <div class=" hide" id="state_field_us">
                    <fieldset class="u-margin-top--flush " id="">
                        <label class="c-form__label" for="state_us">État<span class="is-error"> *</span>
                        </label>

                        <select autocomplete="address-level1" class="c-form__select" data-value-missing="Veuillez sélectionner un état." id="state_us" name="state_us">
                            <option disabled="" selected="" value="">Veuillez sélectionner une option.</option>
                            <option data-state-code="AK" value="Alaska">Alaska</option>
                            <option data-state-code="CA" value="California">Californie</option>
                            <option data-state-code="CO" value="Colorado">Colorado</option>
                            <option data-state-code="FL" value="Florida">Floride</option>
                            <option data-state-code="HI" value="Hawaii">Hawaï</option>
                            <option data-state-code="LA" value="Louisiana">Louisiane</option>
                            <option data-state-code="MT" value="Montana">Montana</option>
                            <option data-state-code="NM" value="New Mexico">Nouveau-Mexique</option>
                        </select>

                        <div class="c-form__inline-error u-margin-top--small u-margin-bottom--small hide" aria-live="polite">
                        </div>
                    </fieldset>
                </div>
            </div>
        </div>

        <div class=" hide" id="state_field_ca">
            <fieldset class="u-margin-top--flush " id="">
                <label class="c-form__label" for="state_ca">Province<span class="is-error"> *</span>
                </label>

                <select autocomplete="address-level1" class="c-form__select" data-value-missing="Veuillez sélectionner une province." id="state_ca" name="state_ca">
                    <option disabled="" selected="" value="">Veuillez sélectionner une option.</option>
                    <option data-province-code="ON" value="Ontario">Ontario</option>
                    <option data-province-code="QC" value="Quebec">Québec</option>
                </select>

                <div class="c-form__inline-error u-margin-top--small u-margin-bottom--small hide" aria-live="polite"></div>
            </fieldset>
        </div>

        <input type="hidden" name="state" id="state" value="">
        </input>

        <fieldset class="u-margin-top--flush " id="">
            <label class="c-form__label" for="country_option">Pays<span class="is-error"> *</span>
            </label>

            <select class="c-form__select" required="" id="country_option" name="country_option" data-value-missing="Veuillez sélectionner un pays.">
                <option value="France" selected="" data-country-code="FR">France</option>
                <option value="Germany" data-country-code="DE">Allemagne</option>
                <option value="Argentina" data-country-code="AR">Argentine</option>
                <option value="Australia" data-country-code="AU">Australie</option>
                <option value="Brazil" data-country-code="BR">Brésil</option>
                <option value="Canada" data-country-code="CA">Canada</option>
                <option value="Côte d’Ivoire" data-country-code="CI">Côte d'Ivoire</option>
                <option value="Cuba" data-country-code="CU">Cuba</option>
                <option value="United Arab Emirates" data-country-code="AE">Émirats arabes unis</option><option value="Ecuador" data-country-code="EC">Équateur</option>
                <option value="Spain" data-country-code="ES">Espagne</option>
                <option value="United States" data-country-code="US">États-Unis</option>
                <option value="Hong Kong" data-country-code="HK">Hong Kong</option>
                <option value="Morocco" data-country-code="MA">Maroc</option>
                <option value="Mexico" data-country-code="MX">Mexique</option>
                <option value="Portugal" data-country-code="PT">Portugal</option>
                <option value="Qatar" data-country-code="QA">Qatar</option>
                <option value="United Kingdom" data-country-code="GB">Royaume-Uni</option>
                <option value="Senegal" data-country-code="SN">Sénégal</option>

            </select>
            <input type="hidden" name="country_code" id="country_code" value="FR" />
            <div class="c-form__inline-error u-margin-top--small u-margin-bottom--small hide" aria-live="polite">
            </div>
        </fieldset>

        <div class="o-two-columns v--even">
            <fieldset class="u-margin-top--flush">
                <label class="c-form__label" for="company">Entreprise<span class="is-error"> *</span>
                </label>

                <input autocomplete="organization" class="c-form__input" data-value-missing="Veuillez indiquer l’endroit où vous travaillez.
                " id="company" maxlength="80" name="company" placeholder="Fiction S.A." required="" type="text" value="" />
                <div class="c-form__inline-error u-margin-bottom--small hide" aria-live="polite">
                </div>
            </fieldset>


            <fieldset class="u-margin-top--flush" id="company_size_wrapper">
                <label class="c-form__label" for="company_size_option">Taille de l’entreprise<span class="is-error"> *</span>
                </label>


                <select class="c-form__select" data-value-missing="Veuillez sélectionner la taille de l’entreprise." id="company_size_option" name="company_size_option" required=""><option disabled="" selected="" value="">Veuillez sélectionner une option</option>
                    <option value="1-100">1-100</option>
                    <option value="101-200">101-200</option>
                    <option value="201-400">201-400</option>
                    <option value="401-1,500">401-1&nbsp;500</option>
                    <option value="1,501-10,000">1&nbsp;501-10&nbsp;000</option>
                    <option value="10,001+">+ de 10&nbsp;001</option>
                </select>

                <div class="c-form__inline-error u-margin-top--small u-margin-bottom--small hide" aria-live="polite">
                </div>
            </fieldset>
        </div>

        <div class="o-two-columns v--even">
            <fieldset class="u-margin-top--flush">
                <label class="c-form__label" for="department_option">Service<span class="is-error"> *</span>
                </label>

                <select class="c-form__select" data-value-missing="Veuillez sélectionner une option pour le service." id="department_option" name="department_option" required="">
                    <option disabled="" selected="" value="">Veuillez sélectionner une option</option>
                    <option value="Engineering">Développement/ingénierie</option>
                    <option value="IT">Informatique</option>
                    <option value="Sales">Ventes</option>
                    <option value="Customer Service">Assistance et succès</option>
                    <option value="Marketing">Marketing</option>
                    <option value="Finance">Finance/juridique/opérations</option>
                    <option value="Human Resources">RH/personnes</option>
                    <option value="Operations">Stratégie/développement de l’entreprise</option>
                </select>

                <div class="c-form__inline-error u-margin-top--small u-margin-bottom--small hide" aria-live="polite">
                </div>
            </fieldset>

            <fieldset class="u-margin-top--flush">
                <label class="c-form__label" for="role_option">Rôle<span class="is-error"> *</span>
                </label>

                <select class="c-form__select" data-value-missing="Veuillez sélectionner une option pour le rôle." id="role_option" name="role_option" required=""><option disabled="" selected="" value="">Veuillez sélectionner une option</option>
                    <option value="CXO">Cadre dirigeant</option>
                    <option value="VP">Vice-président</option>
                    <option value="Director">Directeur</option>
                    <option value="Manager">Responsable</option>
                    <option value="Contributor">Contributeur</option>
                </select>

                <div class="c-form__inline-error u-margin-top--small u-margin-bottom--small hide" aria-live="polite">
                </div>
            </fieldset>
        </div>

        <div class="o-two-columns v--even">
            <fieldset class="u-margin-top--flush">
                <label class="c-form__label" for="phone">Numéro de téléphone<span class="is-error"> *</span>
                </label>
                <input autocomplete="tel" class="c-form__input" data-value-invalid="Veuillez inclure un numéro de téléphone valide.
                " data-value-missing="Veuillez inclure un numéro de téléphone." id="phone" name="phone"
                    pattern="(?=.*[0-9])[- +()\.0-9]{4,}$" placeholder="55-55-55-55-55" required="" type="tel">
                    <div class="c-form__inline-error u-margin-top--small u-margin-bottom--small hide" aria-live="polite">
                    </div>
                </input>
            </fieldset>
        </div>


        <fieldset class="u-margin-top--flush">
            <label class="c-form__label" for="sales_team_help_option">Comment notre équipe de vente peut-elle vous aider&nbsp;?<span class="is-error"> *</span>
            </label>

            <select class="c-form__select" data-value-missing="Veuillez sélectionner une option d’aide pour l’équipe commerciale." id="sales_team_help_option" name="sales_team_help_option" required="">
                <option disabled="" selected="" value="">Veuillez sélectionner une option</option>
                <option value="I want to evaluate Slack for my organization">Je souhaite déterminer si Slack est la bonne solution pour mon organisation</option>
                <option value="I want to understand which Slack plan is right for me">Je souhaite déterminer quel forfait Slack me convient le mieux</option>
                <option value="I want to buy licenses or upgrade">Je souhaite acheter des licences ou passer à un forfait supérieur</option>
                <option value="I have a product question">J’ai une question concernant le produit</option>
                <option value="I need a compliance plan">J’ai besoin d’un plan de conformité</option>
            </select>

            <div class="c-form__inline-error u-margin-top--small u-margin-bottom--small hide" aria-live="polite">
            </div>
        </fieldset>

        <div class="v--padded" aria-hidden="true">
            <fieldset class="u-margin-top--flush">
                <label class="c-form__label" for="comments">Des questions&nbsp;?<span class="u-weight-normal"> (facultatif)</span>
                    <span class="counter" id="comments_counter">
                        <span class="count_remaining"></span>
                    </span>
                </label>
                <textarea class="c-form__input" id="comments" maxlength="500" name="comments" placeholder="Avez-vous des besoins particuliers concernant Slack&nbsp;?"></textarea>
            </fieldset>
        </div>
        <div class="c-form__container c-form__consent-fields">
            <div class="c-form__consent-fields__group-A hide">
                <div class="c-form__container c-form__consent__privacy-notice-language">
                    <label class="c-form__label u-weight-normal u-text--muted">En cliquant sur «&nbsp;Envoyer&nbsp;», je confirme avoir lu la <a data-clog-click="" data-clog-element="link_privacy_policy" href="https://slack.com/intl/fr-fr/privacy-policy" rel="noopener">Règles de confidentialité</a> de Slack.</label>
                </div>
            </div>
        </div>

        <div class="c-form__consent-fields__group-B active">
            <div class="c-form__container c-form__consent__privacy-notice-language">
                <label class="c-form__label u-weight-normal u-text--muted">En cliquant sur «&nbsp;Envoyer&nbsp;», je confirme avoir lu la <a data-clog-click="" data-clog-element="link_privacy_policy" href="https://slack.com/intl/fr-fr/privacy-policy" rel="noopener">Règles de confidentialité</a> de Slack.</label>
            </div>
        </div>

        <div class="c-form__container u-margin-top--small u-margin-bottom--small c-form__checkbox__check c-form__consent__marketing-notice-language">
            <input class="c-form__checkbox c-form__consent__marketing-notice-checkbox" name="marketing_notice_checkbox_inputgroup_b" id="marketing_notice_checkbox_inputgroup_b" type="checkbox" value="unchecked">
                <label class="c-form__label u-weight-normal u-text--muted" for="marketing_notice_checkbox_inputgroup_b">Oui, j’accepte de recevoir des communications marketing à propos de Slack. Si je change d’avis, je peux me désinscrire à tout moment.</label>
                <div class="c-form__inline-error u-margin-top--small u-margin-bottom--small hide" aria-live="polite">
                </div>
            </input>
        </div>

        <div class="c-form__consent-fields__group-C hide">
            <div class="c-form__container u-margin-top--small u-margin-bottom--small c-form__checkbox__check c-form__consent__privacy-notice-language">
                <input class="c-form__checkbox c-form__consent__privacy-notice-checkbox" data-value-missing="Veuillez accepter les Règles de confidentialité.
                " id="privacy_notice_checkbox_input" name="privacy_notice_checkbox_input" type="checkbox" value="unchecked" />
                <label class="c-form__label u-weight-normal u-text--muted" for="privacy_notice_checkbox_input">J’accepte la <a data-clog-click="" data-clog-element="link_privacy_policy" href="https://slack.com/intl/fr-fr/privacy-policy" rel="noopener">Règles de confidentialité</a>
                    et la gestion de mes données personnelles. Je consens notamment au transfert de mes données personnelles vers des pays étrangers, y compris les États-Unis, à des fins d’hébergement et de traitement des informations comme décrit dans les Règles de confidentialité.
                    <span class="is-error"> *</span>
                </label>

                <div class="c-form__inline-error u-margin-top--small u-margin-bottom--small hide" aria-live="polite">
                </div>
            </div>
        </div>

        <div class="c-form__container u-margin-top--small u-margin-bottom--small c-form__checkbox__check c-form__consent__marketing-notice-language">
            <input class="c-form__checkbox c-form__consent__marketing-notice-checkbox" name="marketing_notice_checkbox_inputgroup_c"
                id="marketing_notice_checkbox_inputgroup_c" type="checkbox" value="unchecked" />
            <label class="c-form__label u-weight-normal u-text--muted" for="marketing_notice_checkbox_inputgroup_c">Oui, j’accepte de recevoir des communications marketing à propos de Slack.
                Si je change d’avis, je peux me désinscrire à tout moment.</label>
            <div class="c-form__inline-error u-margin-top--small u-margin-bottom--small hide" aria-live="polite">
            </div>
        </div>

        <input type="hidden" name="privacy_notice_checkbox" id="privacy_notice_checkbox" value="">
            <input type="hidden" name="privacy_notice_language" id="privacy_notice_language" value="En cliquant sur «&nbsp;Envoyer&nbsp;», je confirme avoir lu la Règles de confidentialité de Slack.">
                <input type="hidden" name="marketing_notice_checkbox" id="marketing_notice_checkbox" value="unchecked">
                    <input type="hidden" name="marketing_notice_language" id="marketing_notice_language" value="Oui, j’accepte de recevoir des communications marketing à propos de Slack. Si je change d’avis, je peux me désinscrire à tout moment.">
                    </input>
                </input>
            </input>
        </input>

        <div class="c-form__container">
            <label class="c-form__label u-weight-normal is-error">Les champs marqués d’un astérisque (*) sont obligatoires.
            </label>
        </div>

        <div class="c-form__container c-form__container--timezone">
            <label class="c-form__label" for="timezone">Timezone</label>
            <input name="timezone" type="text" id="timezone" autocomplete="user-timezone" tabindex="-1" />
        </div>

        <script type="text/javascript">

            var setUp Inputs = function() { 
if(!window.ga) return; window.ga(function()) {
var tracker = window.ga.getAll()[0];
            var trackingId = tracker.get('trackingId');
            var clientId = tracker.get('clientId');
            document.getElementById('GATRACKID').value = trackingId;
            document.getElementById('GACLIENTID').value = clientId;
            window.addEventListener('load', function(event)) {setUpInputs()
            }


        </script>
        <input type="hidden" id="GACLIENTID" name="GACLIENTID" value="466920999.1644176029">
            <input type="hidden" id="GATRACKID" name="GATRACKID" value="UA-56978219-1">
                <div class="c-form__container">
                    <button class="c-button c-form__action v--primary u-margin-top--medium u-margin-bottom--flush" data-clog-click="" data-clog-params="click_target=contact_sales_form_submit" data-clog-ui-element="form_submit" id="contact_sales_form_submit" type="submit">Envoyer</button>
                </div>
            </input>
        </input>

        <input type="hidden" name="done" value="1" required="">
            <input type="hidden" name="form_type" id="form_type" value="contact_sales_form">
                <input type="hidden" name="utm_medium" value="">
                    <input type="hidden" name="utm_source" value="">
                        <input type="hidden" name="utm_campaign" value="">
                            <input type="hidden" name="utm_term" value="">
                                <input type="hidden" name="utm_content" value="">
                                    <input type="hidden" name="url_params" value="https://slack.com/intl/fr-fr/contact-sales?geocode=fr-fr">
                                        <input type="hidden" name="campaign" value="701f1000002zYCWAA2">
                                            <input type="hidden" name="referral_url" value="">
                                                <input type="hidden" name="placement" value="">
                                                </input>
                                            </input>
                                        </input>
                                    </input>
                                </input>
                            </input>
                        </input>
                    </input>
                </input>
            </input>
        </input>

    </section>

</main >






export default formulaire;